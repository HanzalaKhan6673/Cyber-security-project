# Directory Traversal Vulnerabilities  
## Exploiting and Mitigating Directory Traversal Vulnerabilities: A Security Report  

**Report by:**  
Hamza Bozdar (242370)  
Ahmed Najam (242320)  
Hanzala Khan (242302)  
Hasnan Ahmed (242366)

## Table of Contents  
- [Directory Traversal Vulnerabilities](#directory-traversal-vulnerabilities)
  - [Exploiting and Mitigating Directory Traversal Vulnerabilities: A Security Report](#exploiting-and-mitigating-directory-traversal-vulnerabilities-a-security-report)
  - [Table of Contents](#table-of-contents)
  - [Introduction](#introduction)
  - [1. Details of the Vulnerability and How It Arises](#1-details-of-the-vulnerability-and-how-it-arises)
    - [Broader Implications of Directory Traversal Vulnerabilities](#broader-implications-of-directory-traversal-vulnerabilities)
  - [2. Detailed Exploitation of the Vulnerability](#2-detailed-exploitation-of-the-vulnerability)
    - [Test Environment Setup](#test-environment-setup)
    - [Additional Test Configurations](#additional-test-configurations)
      - [3.2. Exploitation Steps](#32-exploitation-steps)
    - [Server Response](#server-response)
  - [3. Tools Used to Exploit the Vulnerability](#3-tools-used-to-exploit-the-vulnerability)
    - [Burp Suite](#burp-suite)
    - [Firefox](#firefox)
  - [4. Mitigation: How to Patch the Vulnerability](#4-mitigation-how-to-patch-the-vulnerability)
    - [Immediate Mitigations](#immediate-mitigations)
    - [Long-Term Solutions](#long-term-solutions)
  - [5. Broader Implications and Importance of Secure Coding](#5-broader-implications-and-importance-of-secure-coding)
  - [Conclusion](#conclusion)

---

## Introduction  
In today's web applications, security is one of the prime requirements to avoid unauthorized  
access of sensitive data and resources. Directory traversal vulnerabilities occur when an attacker  
manipulates the directory path to access files outside the target directory. This vulnerability can  
lead to unauthorized access to data, server corruption, and even further exploitation of the  
system.  

This report shows the exploitation of a directory traversal vulnerability with Burp Suite. It  
provides the methodology used, the tools involved, and how such vulnerabilities could be  
effectively patched to prevent attacks. Furthermore, this report discusses the wider implications  
of such vulnerabilities, best practices for web application security, and the role of continuous  
monitoring and testing in maintaining robust security measures.

---

## 1. Details of the Vulnerability and How It Arises  
Directory traversal vulnerabilities arise from improper sanitization of user-provided input in file  
path handling. Web servers that fail to validate or restrict file paths allow attackers to include  
directory traversal sequences like `../` in their requests. These sequences enable attackers to  
navigate the server's directory structure and access sensitive files.

For instance, on the test website used in this demonstration, a file path for an image resource  
(e.g., `/images/30.jpg`) could be modified to `../../../../etc/passwd` to access the system's password  
file. This vulnerability arises due to:  
- Failure to validate input file paths.  
- Lack of access controls for critical system directories.  
- Over-reliance on client-side input sanitization.

---

### Broader Implications of Directory Traversal Vulnerabilities  
Directory traversal vulnerabilities can compromise various aspects of an organization’s security:  
1. **Exposure of Sensitive Data**: Attackers may gain access to configuration files, logs, or  
   database credentials stored in files.  
2. **System Compromise**: Accessing files like `/etc/passwd` can provide attackers with system-level  
   information, enabling privilege escalation or further exploits.  
3. **Reputational Damage**: Breaches resulting from such vulnerabilities can erode user trust  
   and tarnish an organization’s reputation.

---

## 2. Detailed Exploitation of the Vulnerability  
### Test Environment Setup  
To demonstrate the exploitation, a controlled test environment was established:  
- **Burp Suite Configuration**: Installed on a Kali Linux machine, Burp Suite was configured to  
  act as a proxy on port 8080. It intercepted and modified HTTP/S traffic between the  
  browser (Firefox) and the server.  
- **Firefox Configuration**: Firefox was set to route all traffic through Burp Suite's proxy by  
  manually configuring the browser's network settings.  

### Additional Test Configurations  
- **Intentionally Vulnerable Website**: The target website was designed with a directory  
  traversal vulnerability to facilitate controlled testing.  
- **Secure Environment**: The test was conducted in a sandboxed environment to prevent  
  unintended consequences.

#### 3.2. Exploitation Steps  
- **Intercepting a Request**: Burp Suite captured an HTTP GET request for an image file  
  (/images/30.jpg) on the vulnerable test website.  
  **Original Request**:  
  `GET /images/30.jpg HTTP/1.1`  
  `Host: vulnerable-website.com`  
  `User-Agent: Mozilla/5.0`  
  `Accept: image/jpeg`  

- **Crafting the Malicious Payload**: The file path in the intercepted request was modified to  
  include a directory traversal payload (`../../../../etc/passwd`).  
  **Modified Request**:  
  `GET /images/../../../../etc/passwd HTTP/1.1`  
  `Host: vulnerable-website.com`  
  `User-Agent: Mozilla/5.0`  
  `Accept: image/jpeg`  

- **Forwarding the Request**: The modified request was forwarded to the server. Due to  
  inadequate sanitization, the server processed the request and returned the contents of  
  the `/etc/passwd` file.

---

### Server Response  
The server responded with the contents of the `/etc/passwd` file, revealing critical system  
information such as usernames and user IDs. Although modern systems do not store passwords  
in this file, the information obtained can assist in further attacks.  
**Example Response**:  
`HTTP/2 200 OK`  
`Content-Type: text/plain`  
`Content-Length: 2316`  
`root:x:0:0:root:/root:/bin/bash`  
`daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin`  
`bin:x:2:2:bin:/bin:/usr/sbin/nologin`  
...

---

## 3. Tools Used to Exploit the Vulnerability  
### Burp Suite  
- **Purpose**: A comprehensive web application security testing tool.  
- **Key Features**:  
  - Intercept: Captures and modifies HTTP/S traffic.  
  - Repeater: Sends customized requests for testing server responses.  
  - Scanner: Identifies common vulnerabilities.  
- **Advantages**:  
  - Intuitive interface.  
  - Support for complex testing workflows.  
  - Extensive documentation and community support.

### Firefox  
- **Purpose**: A browser configured to route traffic through Burp Suite's proxy server.  
- **Key Role**: Facilitated real-time interception and testing of HTTP/S requests.

---

## 4. Mitigation: How to Patch the Vulnerability  
To prevent directory traversal attacks, implement the following measures:

### Immediate Mitigations  
1. **Input Validation**:  
   - Ensure strict validation of user-provided file paths.  
   - Disallow special characters and sequences like `../`.

2. **Access Controls**:  
   - Restrict access to critical directories and files.  
   - Use whitelisting to define accessible directories explicitly.

3. **Logging and Monitoring**:  
   - Log all access attempts to sensitive directories.  
   - Monitor logs for suspicious activity.

### Long-Term Solutions  
1. **Use Secure APIs**:  
   - Employ secure file-handling functions that normalize file paths and restrict  
     directory traversal.  

2. **Regular Security Testing**:  
   - Conduct penetration tests using tools like Burp Suite to identify vulnerabilities.  
   - Regularly update the software to fix known issues.

3. **Developer Training**:  
   - Educate developers on secure coding practices and common vulnerabilities.

4. **Implement Web Application Firewalls (WAFs)**:  
   - WAFs can block malicious payloads in HTTP requests, adding an additional layer  
     of defense.

---

## 5. Broader Implications and Importance of Secure Coding  
This attack underscores the critical need for secure coding practices and robust security  
measures. Organizations must:  
- Adopt a Security-First Approach: Treat security as a fundamental aspect of  
  development rather than an afterthought.  
- Invest in Tools and Training: Equip teams with the tools and knowledge to  
  identify and mitigate vulnerabilities.  
- Promote a Culture of Awareness: Encourage vigilance and proactive measures to  
  address security risks.

---

## Conclusion  
This report highlighted a directory traversal vulnerability and demonstrated its exploitation  
using Burp Suite. By modifying HTTP requests, an attacker successfully accessed sensitive  
system files, illustrating the critical need for secure input handling.  

The use of tools like Burp Suite emphasizes the importance of proactive security testing. To  
mitigate such vulnerabilities, developers must adopt best practices in secure coding and input  
validation, and organizations must perform regular security audits to safeguard their  
applications and data.  

Ultimately, addressing such vulnerabilities requires a combination of technical solutions,  
ongoing education, and a commitment to maintaining high security standards. This case serves  
as a reminder of the evolving threat landscape and the importance of staying vigilant in the face  
of emerging risks.
